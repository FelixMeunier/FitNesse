# validation-ws

Validation Web Service
Details at https://confluence.isvcs.net/display/ITBIET/Validation+microservices

This is an InnerSource: Community-led development project.
Our team is very excited to share this initiative with all the developers who are willing to help and contribute to this project. You can find more information about our project on the Wiki space and the Jira board.