package ca.gc.cra.xzis.validationws.validator;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Validates Canadian Social Insurance Number
 */
public class SocialInsuranceNumber implements Validator {

	private String sin;

	/**
	 * Constructor
	 * @param sin
	 */
	public SocialInsuranceNumber(String sin) {
		this.sin = Validator.normalize(sin);
		this.sin = this.sin.replaceAll(" ", "");
	}
	
	/**
	 * Validate
	 */
	@Override
	public Validation validate(long id) {
		// Check 1: length and starting number
		if (Validator.matchPattern("^\\d{9}$", this.sin)) {
			return new Validation(id, false, "SIN has to be a 9 digits number");
		}

		// Check 2: Luhn Algorithm
		if (!Validator.luhnAlgorithm(this.sin)) {
			return new Validation(id, false, "Failed checksum");
		}
		
		return new Validation(id, true, "");
	}
	
	/**
	 * Getter
	 * @return
	 */
	public String getSin() {
		return sin;
	}

	/**
	 * Setter
	 * @param sin
	 */
	public void setSin(String sin) {
		this.sin = sin;
	}
}
