package ca.gc.cra.xzis.validationws.validator;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Validates International Mobile Equipment Identity
 */
public class InternationalMobileEquipmentIdentity implements Validator {

	/**
	 * Defines different length for two types of IMEI
	 */
	public enum IMEIType {
		IMEI(15),
		IMEISV(16);
		
		private int length;
		
		private IMEIType(int length) {
			this.length = length;
		}
		
		public int getLength() {
			return this.length;
		}
	}
	
	private String imei;
	private IMEIType imeiType;
	private String invalidImeiType;
	
	/**
	 * Constructor
	 * @param imei
	 * @param type
	 */
	public InternationalMobileEquipmentIdentity(String imei, String type) {
		this.imei = Validator.normalize(imei);
		
		if (type != null && !type.isEmpty()) {
			try {
				this.imeiType = IMEIType.valueOf(type.toUpperCase());
			} catch (Exception e) {
				this.invalidImeiType = type;
			}
		}
	}
	
	/**
	 * Validate
	 */
	@Override
	public Validation validate(long id) {

		// Check 1: IMEI given isn't valid
		if (this.invalidImeiType != null) {
			return new Validation(id, false, this.invalidImeiType + " is not a valid IMEI type.");
		}
		
		// Check 2: length
		if (Validator.matchPattern("^\\d{" + this.imeiType.getLength() + "}$", this.imei)) {
			return new Validation(id, false, "IMEI has to be a " + this.imeiType.getLength() + " digits number");
		}

		// Check 3: Luhn Algorithm
		if (!Validator.luhnAlgorithm(this.imei)) {
			return new Validation(id, false, "Failed checksum");
		}
		
		return new Validation(id, true, "");
	} 
}
