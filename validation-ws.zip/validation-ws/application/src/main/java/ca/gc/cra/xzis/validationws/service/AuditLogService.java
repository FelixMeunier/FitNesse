package ca.gc.cra.xzis.validationws.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.cra.xzis.validationws.model.AuditLog;
import ca.gc.cra.xzis.validationws.repository.AuditLogRepository;

@Service
public class AuditLogService implements IAuditLogService {

    @Autowired
    private AuditLogRepository repository;

    @Override
    public List<AuditLog> findAll() {

    	List<AuditLog> auditlog = (List<AuditLog>) repository.findAll();

        return auditlog;
    }
}