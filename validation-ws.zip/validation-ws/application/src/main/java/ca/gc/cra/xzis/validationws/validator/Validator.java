package ca.gc.cra.xzis.validationws.validator;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Validator
 */
public interface Validator {
	
	/**
	 * Validation
	 * 
	 * @return
	 */
	public Validation validate(long id);

	/**
	 * Normalize string - UTF-8 - Space before and after the string - upper case
	 * 
	 * @param value
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String normalize(String value) {
		value = new String(value.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
		value = value.trim().toUpperCase();
		return value;
	}

	/**
	 * Check if the value matches the given pattern
	 * 
	 * @param regex
	 * @param value
	 * @return
	 */
	public static boolean matchPattern(String regex, String value) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(value);
		return matcher.matches();
	}

	/**
	 * Luhn Algorithm used to calculate checksums
	 * 
	 * @param number
	 * @return
	 */
	public static boolean luhnAlgorithm(String number) {
		int[] array = new int[number.length()];

		for (int i = 0; i < number.length(); i++) {
			array[i] = Integer.parseInt(number.charAt(i) + "");

			if (i % 2 == number.length() % 2) {
				array[i] = array[i] * 2;
				array[i] = array[i] > 9 ? array[i] / 10 + array[i] % 10 : array[i];
			}
		}
		int sum = Arrays.stream(array).sum();
		return (sum % 10 == 0);
	}
}