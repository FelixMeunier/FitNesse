package ca.gc.cra.xzis.validationws.model;

import java.sql.Timestamp;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "auditlog")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private Timestamp timestamp;
    private String type;
    private String status;
    private String description;
    
    public AuditLog() {
    }

    public AuditLog(Long id, Timestamp timestamp, String type, String status, String description) {
        this.id = id;
        this.setTimestamp(timestamp);
        this.setType(type);
        this.setStatus(status);
        this.setDescription(description);
    }
    
    /**
     * @return Long
     */
    public Long getId() {
    	return id;
    }
    
	/**
	 * @return Timestamp
	 */
	public Timestamp getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return String
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param String type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return String
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param String status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return String description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
