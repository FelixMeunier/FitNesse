package ca.gc.cra.xzis.validationws;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ca.gc.cra.xzis.validationws.validator.CreditCard;
import ca.gc.cra.xzis.validationws.validator.InternationalMobileEquipmentIdentity;
import ca.gc.cra.xzis.validationws.validator.PostalCode;
import ca.gc.cra.xzis.validationws.validator.SocialInsuranceNumber;
import ca.gc.cra.xzis.validationws.validator.SocialSecurityNumber;
import ca.gc.cra.xzis.validationws.validator.Validator;
import ca.gc.cra.xzis.validationws.validator.ZipCode;

/**
 * Validation Controller Data validation for different types of fields
 * 
 * @author KXL278
 *
 */
@SpringBootApplication
@RestController
public class ValidationController {

	// ID counter
	private final AtomicLong counter = new AtomicLong();

	/**
	 * Main
	 * 
	 * @param String[] args
	 */
	public static void main(String[] args) {
		SpringApplication.run(ValidationController.class, args);
	}

	/**
	 * Validates Canadian postal code
	 * 
	 * @param String value
	 * @param String province
	 * @return Validation
	 */
	@GetMapping("/postalcode")
	public Validation postalCode(@RequestParam(value = "value", defaultValue = "") String value,
			@RequestParam(value = "province", defaultValue = "") String province) {

		Validator validator = new PostalCode(value, province);
		return validator.validate(counter.incrementAndGet());
	}

	/**
	 * Validates American Zip Code
	 * 
	 * @param String value
	 * @param String state
	 * @return Validation
	 */
	@GetMapping("/zipcode")
	public Validation zipCode(@RequestParam(value = "value", defaultValue = "") String value,
			@RequestParam(value = "state", defaultValue = "") String state) {

		Validator validator = new ZipCode(value, state);
		return validator.validate(counter.incrementAndGet());
	}

	/**
	 * Validates Credit card numbers
	 * 
	 * @param String value
	 * @return Validation
	 */
	@GetMapping("/creditcard")
	public Validation creditcard(@RequestParam(value = "value", defaultValue = "") String value) {

		Validator validator = new CreditCard(value);
		return validator.validate(counter.incrementAndGet());
	}

	/**
	 * Validates Canadian Social Insurance Number
	 * 
	 * @param String value
	 * @return Validation
	 */
	@GetMapping("/sin")
	public Validation socialInsuranceNumber(@RequestParam(value = "value", defaultValue = "") String value) {

		Validator validator = new SocialInsuranceNumber(value);
		return validator.validate(counter.incrementAndGet());
	}

	/**
	 * Validates American Social Security Number
	 * 
	 * @param String value
	 * @return Validation
	 */
	@GetMapping("/ssn")
	public Validation socialSecurityNumber(@RequestParam(value = "value", defaultValue = "") String value) {

		Validator validator = new SocialSecurityNumber(value);
		return validator.validate(counter.incrementAndGet());
	}

	/**
	 * Validates IMEI
	 * 
	 * @param String value
	 * @param String type
	 * @return Validation
	 */
	@GetMapping("/imei")
	public Validation validation(@RequestParam(value = "value", defaultValue = "") String value,
			@RequestParam(value = "type", defaultValue = "") String type) {

		Validator validator = new InternationalMobileEquipmentIdentity(value, type);
		return validator.validate(counter.incrementAndGet());
	}
}
