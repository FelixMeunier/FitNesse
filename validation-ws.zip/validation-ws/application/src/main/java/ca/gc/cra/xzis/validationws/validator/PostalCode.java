package ca.gc.cra.xzis.validationws.validator;

import java.util.Arrays;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Canadian Postal Code Validator
 * 
 */
public class PostalCode implements Validator {

	/**
	 * Province and Territories of Canada
	 */
	public enum CanadianProvince {
		AB("T"),
		BC("V"), 
		MB("R"), 
		NB("E"),
		NL("A"),
		NS("B"), 
		NT("X"), 
		NU("X"),
		ON("K", "L", "M", "N", "P"),
		PE("C"),
		QC("G", "H", "J"),
		SK("S"),
		YT("Y");

		private String[] firstLetters;

		private CanadianProvince(String... firstletter) {
			this.firstLetters = firstletter;
		}
		
		public boolean isValid(String firstLetter) {
			return Arrays.stream(this.firstLetters).anyMatch(firstLetter::equals);
		}
		
		public String getErrorMessage() {
			return "Province " + this + " must start with " + String.join(", ", firstLetters);
		}
	}
	private String postalCode;
	private CanadianProvince province = null;
	private String invalidProvince = null;
	
	/**
	 * Constructor
	 * 
	 * @param postalCode
	 * @param province
	 * @throws Exception 
	 */
	public PostalCode(String postalCode, String province) {
		this.postalCode = Validator.normalize(postalCode);
		
		if (province != null && !province.isEmpty()) {
			try {
				this.province = CanadianProvince.valueOf(province.toUpperCase());
			} catch (Exception e) {
				this.invalidProvince = province;
			}
		}
	}

	/**
	 * Validate
	 */
	@Override
	public Validation validate(long id) {

		// Check 1: Province given isn't valid
		if (this.invalidProvince != null) {
			return new Validation(id, false, "Province " + this.invalidProvince + " is not a valid province.");
		}
		
		// Check 2: Postal code must be in the pattern of A1A 1A1 or A1A1A1
		if (!Validator.matchPattern("^[A-Z]\\d[A-Z] ?\\d[A-Z]\\d$", this.postalCode)) {
			return new Validation(id, false, "Postal code does not match A1A 1A1 or A1A1A1");
		}

		// Check 3: postal codes cannot contain the letters D, F, I, O, Q, or U, and cannot start with W or Z
		if (!Validator.matchPattern("[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]", this.postalCode)) {
			return new Validation(id, false,
					"Postal codes cannot contain the letters D, F, I, O, Q, or U, and cannot start with W or Z");
		}

		// Check 4: If province is given, the first letter of the postal code must match its province
		String firstLetter = this.postalCode.substring(0, 1);
		if (this.province != null && !this.province.isValid(firstLetter)) {
			return new Validation(id, false, province.getErrorMessage());
		}	
		return new Validation(id, true, "Correct");
	}
	
	/**
	 * Postal code Getter
	 * @return
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Postal code Setter
	 * @param postalCode
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Canadian Province getter
	 * @return
	 */
	public CanadianProvince getProvince() {
		return province;
	}

	/**
	 * Canadian Province Setter
	 * @param province
	 */
	public void setProvince(CanadianProvince province) {
		this.province = province;
	}
}