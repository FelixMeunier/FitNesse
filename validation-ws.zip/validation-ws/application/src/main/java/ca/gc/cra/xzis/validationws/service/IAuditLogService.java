package ca.gc.cra.xzis.validationws.service;

import java.util.List;

import ca.gc.cra.xzis.validationws.model.AuditLog;

public interface IAuditLogService {
	    List<AuditLog> findAll();
}