package ca.gc.cra.xzis.validationws;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ca.gc.cra.xzis.validationws.model.AuditLog;
import ca.gc.cra.xzis.validationws.service.IAuditLogService;

/**
 * Validation Controller Data validation for different types of fields
 * 
 * @author KXL278
 *
 */
@SpringBootApplication
@Controller
public class AuditLogController {

	@Autowired
	private IAuditLogService auditLogService;

	/**
	 * Main
	 * 
	 * @param String[] args
	 */
	public static void main(String[] args) {
		SpringApplication.run(ValidationController.class, args);
	}

	@GetMapping("/showAuditLog")
	public String findAuditLog(Model model) {

		List<AuditLog> auditlog = (List<AuditLog>) auditLogService.findAll();

		model.addAttribute("auditLog", auditlog);

		return "showAuditLog";
	}
}
