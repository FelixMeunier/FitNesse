package ca.gc.cra.xzis.validationws.validator;

import java.util.Arrays;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Canadian Postal Code Validator
 */
public class ZipCode implements Validator {
	/**
	 * America states and their prefix
	 *
	 */
	public enum AmericanStates {
		CT("0"), MA("0"), ME("0"), NH("0"), NJ("0"), PR("0"), RI("0"), VT("0"), VI("0"), APO_AE("0"), FPO_AE("0"),

		DE("1"), PA("1"), NY("0", "1"),

		DC("2"), MD("2"), NC("2"), SC("2"), VA("2"), WV("2"),

		AL("3"), FL("3"), GA("3"), MS("3"), TN("3"), APO_AA("3"), FPO_AA("3"),

		IN("4"), KY("4"), MI("4"), OH("4"),

		IA("5"), MN("5"), MT("5"), ND("5"), SD("5"), WI("5"),

		IL("6"), KS("6"), MO("6"), NE("6"),

		AR("7"), LA("7"), OK("7"), TX("7"),

		AZ("8"), CO("8"), ID("8"), NM("8"), NV("8"), UT("8"), WY("8"),

		AK("9"), AS("9"), CA("9"), GU("9"), HI("9"), MH("9"), FM("9"), MP("9"), OR("9"), PW("9"), WA("9"), APO_AP("9"),
		FPO_AP("9");

		private String[] firstNumbers;

		private AmericanStates(String... firstNumber) {
			this.firstNumbers = firstNumber;
		}

		public boolean isValid(String firstLetter) {
			return Arrays.stream(this.firstNumbers).anyMatch(firstLetter::equals);
		}

		public String getErrorMessage() {
			return "Province " + this + " must start with " + String.join(", ", firstNumbers);
		}
	}
	
	private String zipCode;
	private AmericanStates state = null;
	private String invalidState = null;

	/**
	 * Constructor
	 * 
	 * @param zipCode
	 * @param state
	 * @throws Exception
	 */
	public ZipCode(String zipCode, String state) {
		this.zipCode = Validator.normalize(zipCode);

		if (state != null && !state.isEmpty()) {
			try {
				this.state = AmericanStates.valueOf(state.toUpperCase());
			} catch (Exception e) {
				this.invalidState = state;
			}
		}
	}

	/**
	 * Validate
	 */
	@Override
	public Validation validate(long id) {
		// Check 1: state given isn't valid
		if (this.invalidState != null) {
			return new Validation(id, false, "State " + this.invalidState + " is not a valid state.");
		}

		// Check 2: pattern check
		if (!Validator.matchPattern("^[0-9]{5}(?:-[0-9]{4})?$", this.zipCode)) {
			return new Validation(id, false, "Postal code does not match A1A 1A1 or A1A1A1");
		}

		// Check 4: If state is given, the first letter of the postal code must match
		// its state
		String firstNumber = this.zipCode.substring(0, 1);
		if (this.state != null && !this.state.isValid(firstNumber)) {
			return new Validation(id, false, state.getErrorMessage());
		}
		return new Validation(id, true, "");
	}
}