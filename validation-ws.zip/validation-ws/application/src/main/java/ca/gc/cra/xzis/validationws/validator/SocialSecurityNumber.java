package ca.gc.cra.xzis.validationws.validator;

import ca.gc.cra.xzis.validationws.Validation;

/**
 * Validates American social security number
 */
public class SocialSecurityNumber implements Validator {

	private String ssn;

	/**
	 * Constructor
	 * @param sin
	 */
	public SocialSecurityNumber(String sin) {
		this.ssn = Validator.normalize(sin);
	}
	
	/**
	 * Validate
	 */
	@Override
	public Validation validate(long id) {
		// Check 1: length, starting number and pattern ^\d{3}-\d{2}-\d{4}$
		if (Validator.matchPattern("^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$", this.ssn)) {
			return new Validation(id, false, "SSN has to be a 9 digits number");
		}

		return new Validation(id, true, "");
	}
	
	/**
	 * Getter
	 * @return
	 */
	public String getSsn() {
		return ssn;
	}

	/**
	 * Setter
	 * @param ssn
	 */
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
}
