package ca.gc.cra.xzis.validationws;

/**
 * Validation
 * @author KXL278
 *
 */
public class Validation {

	private final long id;
	private final Boolean valid;
	private final String errorMessage;

	/**
	 * Validation constructor
	 * @param id
	 * @param valid
	 * @param errorMessage
	 */
	public Validation(long id, Boolean valid, String errorMessage) {
		this.id = id;
		this.valid = valid;
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the valid
	 */
	public Boolean getValid() {
		return valid;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

}
