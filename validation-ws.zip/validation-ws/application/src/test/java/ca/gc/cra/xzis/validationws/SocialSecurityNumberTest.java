package ca.gc.cra.xzis.validationws;

import org.easymock.EasyMock;
import org.junit.Test;

import ca.gc.cra.xzis.validationws.Validation;
import ca.gc.cra.xzis.validationws.validator.SocialSecurityNumber;

public class SocialSecurityNumberTest {

	@Test
	public void testValidate() {
		SocialSecurityNumber socialSecurityNumberMock = EasyMock.mock(SocialSecurityNumber.class);
		socialSecurityNumberMock.setSsn("519608645");
		Validation valueResponce = new Validation(0, false, "");
		EasyMock.expect(socialSecurityNumberMock.validate(0)).andReturn(valueResponce);
	}
}
