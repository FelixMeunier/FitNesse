package ca.gc.cra.xzis.validationws;
import ca.gc.cra.xzis.validationws.ValidationController;

public class TestValidationController {
	private String postalCode; 
	private String province;
	private String zipCode; 
	private String state;
	private String creditCard;
	private String sin; 
	private String ssn;
	private String imei;
	private String type;
	
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	public void setSin(String sin) {
		this.sin = sin;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public void setType(String type) {
		this.type = type;
	}	

	public String postalCodeTest() {
		ValidationController valid = new ValidationController();
		Validation result = valid.postalCode(postalCode, province);
		return String.valueOf(result.getValid()); 
	}
	
	public String zipCodeTest() {
		ValidationController valid = new ValidationController();
		Validation result = valid.zipCode(zipCode, state);
		return String.valueOf(result.getValid());
	}
	
	public String socialInsuranceNumberTest() {
		ValidationController valid = new ValidationController();
		Validation result = valid.socialInsuranceNumber(sin);
		return String.valueOf(result.getValid());
	}
	
	public String creditcardTest() {
		ValidationController valid = new ValidationController();
		Validation result = valid.creditcard(creditCard);
		return String.valueOf(result.getValid());
	}
	
	public String socialSecurityNumberTest() {
		ValidationController valid = new ValidationController();
		Validation result = valid.socialSecurityNumber(ssn);
		return String.valueOf(result.getValid());
	}
	
	public String validation() {
		ValidationController valid = new ValidationController();
		Validation result = valid.validation(imei, type);
		return String.valueOf(result.getValid());
	}	

}
