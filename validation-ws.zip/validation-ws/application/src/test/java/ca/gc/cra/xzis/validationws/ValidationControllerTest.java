package ca.gc.cra.xzis.validationws;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.easymock.EasyMock;
import org.junit.Test;


import ca.gc.cra.xzis.validationws.ValidationController;
import ca.gc.cra.xzis.validationws.Validation;
import ca.gc.cra.xzis.validationws.validator.SocialInsuranceNumber;



public class ValidationControllerTest extends ValidationController {
	Validation response;
	String arg;
	String type;
	String value;
	String aPOSTALCODE = "K1A 1A1";
	String aType = "PostalCode";
	String aType2 = "creditcard";
	
	@Test
	public void testValidateMock() {
		SocialInsuranceNumber socialInsuranceNumberMock = EasyMock.mock(SocialInsuranceNumber.class);
		socialInsuranceNumberMock.setSin("519608645");
		Validation valueResponce = new Validation(0, false, "");
		EasyMock.expect(socialInsuranceNumberMock.validate(0)).andReturn(valueResponce);
	}
	
	@Test
	public void testValidate1() {
		type = "PostalCodea";
		value = "K1A 1A1";
		arg = "on";
		response = postalCode(value, arg);
		assertTrue(response.getValid());
	}
	
	@Test
	public void testValidate2() {
		type = "PostalCodea";
		value = aPOSTALCODE;
		arg = "on";
		response = postalCode(value, arg);
		assertTrue(response.getValid());
	}

	@Test
	public void testValidate3() {
		arg = "on";
		type = aType;
		value = "K1A A1";
		response = postalCode(value, arg);
		assertFalse(response.getValid());
	}
	
	@Test
	public void testValidate4() {
		arg = "on";
		type = aType;
		value = "w1A 1A1";
		response = postalCode(value, arg);
		assertFalse(response.getValid());	
	}
	
	@Test
	public void testValidate5() {
		arg = "on";
		type = aType;
		value = aPOSTALCODE;
		response = postalCode(value, arg);
		assertTrue(response.getValid());
	}
	
	@Test
	public void testValidate6() {
		arg = "";
		type = aType2;
		value = "5196081888500245";
		response = postalCode(value, arg);
		assertFalse(response.getValid());
	}
	
	@Test
	public void testValidate7() {
		arg = "";
		type = aType2;
		value = "519608645";
		response = postalCode(value, arg);
		assertFalse(response.getValid());
	}
	
	/*@Test
	public void testValidate8() {
		arg = "";
		type = aType2;
		value = "5196081888500645";
		response = postalCode(value, arg);
		assertFalse(response.getValid());
	}*/
}
