package ca.gc.cra.xzis.validationws;

import org.easymock.EasyMock;
import org.junit.Test;

import ca.gc.cra.xzis.validationws.Validation;
import ca.gc.cra.xzis.validationws.validator.PostalCode;
import ca.gc.cra.xzis.validationws.validator.PostalCode.CanadianProvince;

public class PostalCodeTest {

	private static final CanadianProvince canadianProvince = CanadianProvince.BC;

	@Test
	public void testValidate() {
		PostalCode postalCodeMock = EasyMock.mock(PostalCode.class);
		postalCodeMock.setPostalCode("K0E 1S0");
		postalCodeMock.setProvince(canadianProvince );
		Validation valueResponce = new Validation(0, true, "");
		EasyMock.expect(postalCodeMock.validate(0)).andReturn(valueResponce);
	}
}
