Author: Felix Meunier

Target contains the fitnesse jar file: fitnesse-20210516.jar
pom.xml contains the configuration for building the image using Maven

To create an image from the jar:
- Open CMD
- cd to FitNesseDemo
- Enter: mvn jib:build

To run the image from the jar:
- Open CMD
- Enter: Docker run -v fitnesse-data:/FitNesseRoot -d -p 80:80 felixmeunier/fitnessedemo:latest
- Open a browser and navigate to localhost:80